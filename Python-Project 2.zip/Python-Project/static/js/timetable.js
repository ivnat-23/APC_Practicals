// Timetable view interactivity and live conflict detection

document.addEventListener('DOMContentLoaded', () => {
    const slotEditModal = document.getElementById('slotEditModal');
    const conflictAlertBox = document.getElementById('conflictAlertBox');
    const formDay = document.getElementById('modal_day_of_week');
    const formSlot = document.getElementById('modal_slot_number');
    const formFaculty = document.getElementById('modal_faculty_id');
    const formRoom = document.getElementById('modal_room_id');
    const formBatch = document.getElementById('modal_batch_name');
    const formEntryId = document.getElementById('modal_entry_id');
    const formSubmitBtn = document.getElementById('modal_submit_btn');
    const timetableId = document.getElementById('current_timetable_id')?.value;

    // 1. Batch Filter Buttons
    const batchFilterBtns = document.querySelectorAll('.batch-filter-btn');
    batchFilterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            batchFilterBtns.forEach(b => b.classList.remove('btn-primary'));
            batchFilterBtns.forEach(b => b.classList.add('btn-secondary'));
            btn.classList.remove('btn-secondary');
            btn.classList.add('btn-primary');

            const selectedBatch = btn.getAttribute('data-batch');
            const allCards = document.querySelectorAll('.slot-card');

            allCards.forEach(card => {
                const cardBatch = card.getAttribute('data-batch') || 'ALL';
                if (selectedBatch === 'ALL') {
                    card.style.display = '';
                } else {
                    if (cardBatch === 'ALL' || cardBatch === selectedBatch) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                }
            });
        });
    });

    // 2. Open Slot Edit Modal (from clicking slot card or empty slot)
    window.openSlotEditModal = function(entryData) {
        if (!slotEditModal) return;

        document.getElementById('modal_entry_id').value = entryData.id || '';
        document.getElementById('modal_day_of_week').value = entryData.day || 'Monday';
        document.getElementById('modal_slot_number').value = entryData.slot || '1';
        document.getElementById('modal_subject_id').value = entryData.subject_id || '';
        document.getElementById('modal_faculty_id').value = entryData.faculty_id || '';
        document.getElementById('modal_room_id').value = entryData.room_id || '';
        document.getElementById('modal_entry_type').value = entryData.entry_type || 'Theory';
        document.getElementById('modal_batch_name').value = entryData.batch_name || 'ALL';

        const modalTitle = document.getElementById('modalTitle');
        if (entryData.id) {
            modalTitle.innerText = `Edit Lecture/Lab Slot (${entryData.day} - Slot ${entryData.slot})`;
            document.getElementById('deleteSlotForm').style.display = 'block';
            document.getElementById('deleteSlotForm').action = `/timetable/${timetableId}/delete-slot/${entryData.id}`;
        } else {
            modalTitle.innerText = `Assign Class to Empty Slot (${entryData.day} - Slot ${entryData.slot})`;
            document.getElementById('deleteSlotForm').style.display = 'none';
        }

        // Trigger real-time conflict check
        runConflictCheck();
        openModal('slotEditModal');
    };

    // 3. Live Conflict Checking on Input Change
    function runConflictCheck() {
        if (!conflictAlertBox) return;

        const day = formDay?.value;
        const slot = formSlot?.value;
        const facultyId = formFaculty?.value;
        const roomId = formRoom?.value;
        const entryId = formEntryId?.value;
        const batch = formBatch?.value;

        if (!day || !slot) return;

        fetch('/api/check_conflict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                timetable_id: timetableId,
                day_of_week: day,
                slot_number: slot,
                faculty_id: facultyId,
                room_id: roomId,
                exclude_entry_id: entryId,
                batch_name: batch
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.has_conflict) {
                conflictAlertBox.style.display = 'block';
                conflictAlertBox.className = 'flash-message flash-danger';
                conflictAlertBox.innerHTML = `
                    <div>
                        <strong>⚠️ Schedule Conflict Detected!</strong>
                        <ul style="margin: 4px 0 0 16px; font-size: 12px;">
                            ${data.conflicts.map(c => `<li>${c}</li>`).join('')}
                        </ul>
                    </div>
                `;
            } else {
                conflictAlertBox.style.display = 'block';
                conflictAlertBox.className = 'flash-message flash-success';
                conflictAlertBox.innerHTML = `<span>✓ Conflict-free slot! Faculty and Classroom are available.</span>`;
            }
        })
        .catch(err => {
            console.error("Conflict check failed:", err);
        });
    }

    [formDay, formSlot, formFaculty, formRoom, formBatch].forEach(elem => {
        if (elem) {
            elem.addEventListener('change', runConflictCheck);
        }
    });
});
