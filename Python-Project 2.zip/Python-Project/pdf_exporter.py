import os
from reportlab.lib.pagesizes import letter, landscape, A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from database import get_db_connection

def generate_pdf(timetable_id, output_path):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Timetable metadata
    tt = cursor.execute("""
        SELECT t.*, d.code as dept_code, d.name as dept_name,
               div.name as div_name, div.class_coordinator, div.student_count
        FROM timetables t
        JOIN departments d ON t.dept_id = d.id
        JOIN divisions div ON t.division_id = div.id
        WHERE t.id = ?
    """, (timetable_id,)).fetchone()

    if not tt:
        conn.close()
        raise ValueError("Timetable not found.")

    # Time slots
    slots = cursor.execute("""
        SELECT DISTINCT slot_number, start_time, end_time, is_break, break_name
        FROM time_slots
        WHERE day_of_week = 'Monday'
        ORDER BY slot_number ASC
    """).fetchall()

    # Timetable entries
    raw_entries = cursor.execute("""
        SELECT te.*, s.short_name as subject_name, s.name as full_subject_name,
               s.subject_code, f.faculty_code, f.name as faculty_name,
               r.room_number
        FROM timetable_entries te
        LEFT JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON te.faculty_id = f.id
        LEFT JOIN rooms r ON te.room_id = r.id
        WHERE te.timetable_id = ?
        ORDER BY te.day_of_week, te.slot_number, te.batch_name ASC
    """, (timetable_id,)).fetchall()

    # Subjects legend
    legend_subjects = cursor.execute("""
        SELECT DISTINCT s.subject_code, s.name as subject_name, s.short_name,
               s.subject_type, s.lecture_hours_per_week, s.practical_hours_per_week,
               f.name as faculty_name, f.faculty_code
        FROM timetable_entries te
        JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON te.faculty_id = f.id
        WHERE te.timetable_id = ?
        ORDER BY s.subject_code ASC
    """, (timetable_id,)).fetchall()

    # Settings
    settings_rows = cursor.execute("SELECT key, value FROM system_settings").fetchall()
    settings = {r['key']: r['value'] for r in settings_rows}

    conn.close()

    # Build grid mapping: grid[day][slot] = list of text representations
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    grid = {d: {s['slot_number']: [] for s in slots} for d in days}

    for e in raw_entries:
        day = e['day_of_week']
        slot = e['slot_number']
        if day in grid and slot in grid[day]:
            if e['entry_type'] == 'Practical':
                batch = e['batch_name'] or 'Lab'
                sub = e['subject_name'] or 'PRAC'
                room = e['room_number'] or ''
                fac = e['faculty_code'] or ''
                grid[day][slot].append(f"<b>{batch}:</b> {sub} ({room})")
            elif e['entry_type'] == 'Theory':
                sub = e['subject_name'] or 'Theory'
                room = e['room_number'] or ''
                fac = e['faculty_code'] or ''
                grid[day][slot].append(f"<b>{sub}</b><br/>{room} | {fac}")
            elif e['entry_type'] == 'Tutorial':
                sub = e['subject_name'] or 'Tut'
                fac = e['faculty_code'] or ''
                grid[day][slot].append(f"<b>{sub} (Tut)</b><br/>{fac}")
            else:
                grid[day][slot].append(f"<i>{e['entry_type']}</i>")

    # Setup ReportLab Doc in Landscape A4 for wide table fit
    doc = SimpleDocTemplate(
        output_path,
        pagesize=landscape(A4),
        leftMargin=20,
        rightMargin=20,
        topMargin=20,
        bottomMargin=20
    )

    styles = getSampleStyleSheet()

    # Custom styles
    header_title_style = ParagraphStyle(
        'HeaderTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=15,
        leading=18,
        textColor=colors.HexColor('#0a2558'),
        alignment=1 # Center
    )

    header_sub_style = ParagraphStyle(
        'HeaderSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=12,
        textColor=colors.HexColor('#334155'),
        alignment=1
    )

    table_cell_style = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7,
        leading=9,
        alignment=1
    )

    table_break_style = ParagraphStyle(
        'TableBreak',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=7,
        leading=9,
        textColor=colors.HexColor('#9a3412'),
        alignment=1
    )

    story = []

    # 1. Header with Official DYPCET Logo
    logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'images', 'DYPCET.png')
    if not os.path.exists(logo_path):
        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'images', 'logo.png')
    header_data = []

    logo_img = None
    if os.path.exists(logo_path):
        try:
            logo_img = Image(logo_path, width=0.85*inch, height=0.85*inch)
        except Exception:
            logo_img = None

    college_text = f"""
    <b>{settings.get('college_name', 'D. Y. PATIL COLLEGE OF ENGINEERING & TECHNOLOGY')}</b><br/>
    <font size=8 color="#475569">{settings.get('college_subtitle', 'Autonomous Institute | Accredited A Grade by NAAC | Kolhapur - 416006')}</font><br/>
    <font size=10 color="#0f2b66"><b>DEPARTMENT OF {tt['dept_name'].upper()}</b></font><br/>
    <font size=8.5 color="#1e293b"><b>CLASS TIMETABLE (ACADEMIC YEAR {tt['academic_year']}, {tt['term'].upper()})</b></font><br/>
    <font size=8 color="#2563eb"><b>Class: {tt['year_name']} (Semester {tt['semester']}) | Division: {tt['div_name']} | Coordinator: {tt['class_coordinator'] or 'Faculty Incharge'}</b></font>
    """

    if logo_img:
        header_table = Table([[logo_img, Paragraph(college_text, header_title_style)]], colWidths=[1.1*inch, 9.8*inch])
        header_table.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        story.append(header_table)
    else:
        story.append(Paragraph(college_text, header_title_style))

    story.append(Spacer(1, 8))

    # 2. Main Timetable Table
    # Columns: Day/Time + Slots
    table_headers = [Paragraph("<b>Day / Time</b>", table_cell_style)]
    for s in slots:
        if s['is_break']:
            txt = f"<b>{s['break_name']}</b><br/><font size=6>{s['start_time']}-{s['end_time']}</font>"
            table_headers.append(Paragraph(txt, table_break_style))
        else:
            txt = f"<b>Slot {s['slot_number']}</b><br/><font size=6>{s['start_time']}-{s['end_time']}</font>"
            table_headers.append(Paragraph(txt, table_cell_style))

    grid_data = [table_headers]

    for day in days:
        row = [Paragraph(f"<b>{day}</b>", table_cell_style)]
        for s in slots:
            slot_num = s['slot_number']
            if s['is_break']:
                row.append(Paragraph(f"<b>{s['break_name']}</b>", table_break_style))
            else:
                entries_txt = "<br/>".join(grid[day][slot_num]) if grid[day][slot_num] else "<font color='#94a3b8'>-</font>"
                row.append(Paragraph(entries_txt, table_cell_style))
        grid_data.append(row)

    # Column widths calculation: total ~ 11.2 inches
    col_w = [0.9*inch]
    for s in slots:
        if s['is_break']:
            col_w.append(0.8*inch)
        else:
            col_w.append(1.06*inch)

    tt_table = Table(grid_data, colWidths=col_w, repeatRows=1)
    tt_style = [
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0a2558')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
        ('BACKGROUND', (0, 1), (0, -1), colors.HexColor('#f1f5f9')),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]

    # Highlight break columns
    for idx, s in enumerate(slots):
        if s['is_break']:
            col_idx = idx + 1
            tt_style.append(('BACKGROUND', (col_idx, 1), (col_idx, -1), colors.HexColor('#ffedd5')))

    tt_table.setStyle(TableStyle(tt_style))
    story.append(tt_table)

    story.append(Spacer(1, 10))

    # 3. Subject and Faculty Legend (2-column compact table)
    legend_title = Paragraph("<b>Course & Faculty Allotment Details:</b>", ParagraphStyle('LT', parent=styles['Normal'], fontSize=8, fontName='Helvetica-Bold', textColor=colors.HexColor('#0a2558')))
    story.append(legend_title)
    story.append(Spacer(1, 4))

    legend_rows = [[
        Paragraph("<b>Code</b>", table_cell_style),
        Paragraph("<b>Subject Name</b>", table_cell_style),
        Paragraph("<b>Type</b>", table_cell_style),
        Paragraph("<b>Faculty Incharge</b>", table_cell_style),
        Paragraph("<b>Code</b>", table_cell_style),
        Paragraph("<b>Load (Th/Pr)</b>", table_cell_style),
    ]]

    for sub in legend_subjects:
        th = sub['lecture_hours_per_week'] or 0
        pr = sub['practical_hours_per_week'] or 0
        load_txt = f"{th} Th / {pr} Pr"
        legend_rows.append([
            Paragraph(sub['subject_code'], table_cell_style),
            Paragraph(sub['subject_name'], table_cell_style),
            Paragraph(sub['subject_type'], table_cell_style),
            Paragraph(sub['faculty_name'] or 'TBD', table_cell_style),
            Paragraph(sub['faculty_code'] or '-', table_cell_style),
            Paragraph(load_txt, table_cell_style),
        ])

    leg_table = Table(legend_rows, colWidths=[0.9*inch, 3.4*inch, 1.2*inch, 2.5*inch, 1.0*inch, 1.2*inch])
    leg_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e2e8f0')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 2),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
    ]))
    story.append(leg_table)

    story.append(Spacer(1, 14))

    # 4. Official Authority Signatures
    sig_data = [
        [
            Paragraph("<b>Timetable Coordinator</b><br/><br/>__________________", table_cell_style),
            Paragraph("<b>Head of Department</b><br/><br/>__________________", table_cell_style),
            Paragraph("<b>Dean Academics</b><br/><br/>__________________", table_cell_style),
            Paragraph("<b>Principal</b><br/><br/>__________________", table_cell_style),
        ]
    ]
    sig_table = Table(sig_data, colWidths=[2.7*inch, 2.7*inch, 2.7*inch, 2.7*inch])
    sig_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(sig_table)

    # Build PDF
    doc.build(story)
    return output_path
