import os
import io
import json
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, Response, session
from database import (
    init_db, get_db_connection, get_all_departments, get_all_faculty,
    get_all_rooms, get_all_subjects, get_all_divisions, get_time_slots,
    get_system_settings, seed_default_data,
    get_user_by_id, get_user_by_username, verify_user, create_user
)
from generator import TimetableGenerator, check_slot_conflict
from pdf_exporter import generate_pdf
from excel_exporter import generate_excel

app = Flask(__name__)
app.secret_key = 'dypcet-kolhapur-timetable-secret-key-2026'

# Ensure DB initialized on startup
with app.app_context():
    init_db()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please sign in to access the Timetable Portal.", "warning")
            return redirect(url_for('landing', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@app.context_processor
def inject_global_data():
    settings = get_system_settings()
    current_day = datetime.now().strftime('%A')
    departments = get_all_departments()
    current_user = None
    if 'user_id' in session:
        current_user = get_user_by_id(session['user_id'])
    return {
        'settings': settings,
        'current_day': current_day,
        'nav_departments': departments,
        'current_user': current_user
    }

# ==========================================
# AUTHENTICATION & LANDING PAGE
# ==========================================
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('landing.html')

@app.route('/landing')
def landing():
    return render_template('landing.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        # Traditional Authentication Only: Username & Password
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = verify_user(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['full_name'] = user['full_name']
            session['role'] = user['role']
            session['dept_id'] = user['dept_id']
            flash(f"Welcome back, {user['full_name']}!", "success")
            next_url = request.args.get('next')
            return redirect(next_url or url_for('dashboard'))
        else:
            flash("Invalid username or password. Please try again.", "danger")

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        role = request.form.get('role', default='Faculty')
        dept_id = request.form.get('dept_id', type=int) or 1

        if not username or not password or not full_name:
            flash("Username, password, and full name are required.", "danger")
            return redirect(url_for('login'))

        existing = get_user_by_username(username)
        if existing:
            flash("Username already taken. Please choose another.", "danger")
            return redirect(url_for('login'))

        uid = create_user(username, password, full_name, email, role, dept_id)
        session['user_id'] = uid
        session['username'] = username
        session['full_name'] = full_name
        session['role'] = role
        session['dept_id'] = dept_id
        flash("Registration successful! Welcome to DYPCET Timetable Portal.", "success")
        return redirect(url_for('dashboard'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("You have been signed out successfully.", "info")
    return redirect(url_for('landing'))

# ==========================================
# 1. EXECUTIVE DASHBOARD
# ==========================================
@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Statistics
    total_depts = cursor.execute("SELECT COUNT(*) FROM departments").fetchone()[0]
    total_faculty = cursor.execute("SELECT COUNT(*) FROM faculty WHERE is_active = 1").fetchone()[0]
    total_rooms = cursor.execute("SELECT COUNT(*) FROM rooms WHERE is_active = 1").fetchone()[0]
    total_subjects = cursor.execute("SELECT COUNT(*) FROM subjects").fetchone()[0]
    total_timetables = cursor.execute("SELECT COUNT(*) FROM timetables").fetchone()[0]
    total_divisions = cursor.execute("SELECT COUNT(*) FROM divisions").fetchone()[0]

    # Recent Timetables
    recent_timetables = cursor.execute("""
        SELECT t.*, d.code as dept_code, d.name as dept_name, div.name as div_name
        FROM timetables t
        JOIN departments d ON t.dept_id = d.id
        JOIN divisions div ON t.division_id = div.id
        ORDER BY t.created_at DESC
        LIMIT 5
    """).fetchall()

    # Department wise faculty & courses count
    dept_stats = cursor.execute("""
        SELECT d.id, d.code, d.name,
               (SELECT COUNT(*) FROM faculty f WHERE f.dept_id = d.id) as faculty_count,
               (SELECT COUNT(*) FROM subjects s WHERE s.dept_id = d.id) as subject_count,
               (SELECT COUNT(*) FROM divisions div WHERE div.dept_id = d.id) as division_count
        FROM departments d
        ORDER BY d.code ASC
    """).fetchall()

    # Room Utilization summary
    classrooms_count = cursor.execute("SELECT COUNT(*) FROM rooms WHERE room_type = 'Classroom' AND is_active = 1").fetchone()[0]
    labs_count = cursor.execute("SELECT COUNT(*) FROM rooms WHERE room_type LIKE '%Lab%' AND is_active = 1").fetchone()[0]

    conn.close()

    return render_template(
        'dashboard.html',
        total_depts=total_depts,
        total_faculty=total_faculty,
        total_rooms=total_rooms,
        total_subjects=total_subjects,
        total_timetables=total_timetables,
        total_divisions=total_divisions,
        recent_timetables=recent_timetables,
        dept_stats=dept_stats,
        classrooms_count=classrooms_count,
        labs_count=labs_count
    )

# ==========================================
# 2. TIMETABLE VIEWS & MANAGEMENT
# ==========================================
@app.route('/timetables')
@login_required
def timetables_list():
    dept_filter = request.args.get('dept_id', type=int)
    sem_filter = request.args.get('semester', type=int)

    conn = get_db_connection()
    query = """
        SELECT t.*, d.code as dept_code, d.name as dept_name, div.name as div_name,
               div.class_coordinator, div.student_count
        FROM timetables t
        JOIN departments d ON t.dept_id = d.id
        JOIN divisions div ON t.division_id = div.id
        WHERE 1=1
    """
    params = []
    if dept_filter:
        query += " AND t.dept_id = ?"
        params.append(dept_filter)
    if sem_filter:
        query += " AND t.semester = ?"
        params.append(sem_filter)

    query += " ORDER BY t.created_at DESC"
    all_tt = conn.execute(query, params).fetchall()
    depts = conn.execute("SELECT * FROM departments ORDER BY code ASC").fetchall()
    conn.close()

    return render_template('timetables_list.html', timetables=all_tt, departments=depts,
                           selected_dept=dept_filter, selected_sem=sem_filter)

@app.route('/timetable/<int:timetable_id>')
@login_required
def view_timetable(timetable_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    tt = cursor.execute("""
        SELECT t.*, d.code as dept_code, d.name as dept_name, d.hod_name,
               div.name as div_name, div.class_coordinator, div.student_count, div.batches_count
        FROM timetables t
        JOIN departments d ON t.dept_id = d.id
        JOIN divisions div ON t.division_id = div.id
        WHERE t.id = ?
    """, (timetable_id,)).fetchone()

    if not tt:
        conn.close()
        flash("Timetable not found.", "danger")
        return redirect(url_for('timetables_list'))

    slots = cursor.execute("""
        SELECT DISTINCT slot_number, start_time, end_time, is_break, break_name
        FROM time_slots
        WHERE day_of_week = 'Monday'
        ORDER BY slot_number ASC
    """).fetchall()

    entries = cursor.execute("""
        SELECT te.*, s.name as subject_name, s.short_name, s.color as subject_color, s.subject_code,
               f.name as faculty_name, f.faculty_code, f.color as faculty_color,
               r.room_number, r.room_type
        FROM timetable_entries te
        LEFT JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON te.faculty_id = f.id
        LEFT JOIN rooms r ON te.room_id = r.id
        WHERE te.timetable_id = ?
        ORDER BY te.day_of_week, te.slot_number, te.batch_name ASC
    """, (timetable_id,)).fetchall()

    subjects_summary = cursor.execute("""
        SELECT DISTINCT s.id, s.subject_code, s.name, s.short_name, s.subject_type,
               s.lecture_hours_per_week, s.practical_hours_per_week, s.tutorial_hours_per_week,
               s.credits, s.color, f.name as faculty_name, f.faculty_code
        FROM timetable_entries te
        JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON s.primary_faculty_id = f.id
        WHERE te.timetable_id = ?
        ORDER BY s.subject_code ASC
    """, (timetable_id,)).fetchall()

    all_faculty = cursor.execute("SELECT id, name, faculty_code FROM faculty WHERE is_active = 1 ORDER BY name ASC").fetchall()
    all_rooms = cursor.execute("SELECT id, room_number, room_type FROM rooms WHERE is_active = 1 ORDER BY room_number ASC").fetchall()
    all_subjects = cursor.execute("SELECT id, name, short_name, subject_code FROM subjects WHERE dept_id = ? AND semester = ? ORDER BY name ASC",
                                  (tt['dept_id'], tt['semester'])).fetchall()

    conn.close()

    # Organize entries into grid structure: grid[day][slot] = [entries...]
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    grid = {day: {s['slot_number']: [] for s in slots} for day in days}

    for e in entries:
        day = e['day_of_week']
        slot = e['slot_number']
        if day in grid and slot in grid[day]:
            grid[day][slot].append(dict(e))

    # Dynamically extract unique non-ALL batches
    db_batches = [e['batch_name'] for e in entries if e['batch_name'] and e['batch_name'] != 'ALL']
    unique_batches = sorted(list(set(db_batches)))
    if not unique_batches:
        pfx = 'T' if 'TY' in (tt['div_name'] or tt['year_name'] or '') else 'A'
        unique_batches = [f"{pfx}{i+1}" for i in range(tt['batches_count'] or 3)]
    batches = unique_batches

    roman_map = {1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V', 6: 'VI', 7: 'VII', 8: 'VIII'}
    semester_roman = roman_map.get(tt['semester'], str(tt['semester']))

    return render_template(
        'timetable_view.html',
        tt=tt,
        slots=slots,
        days=days,
        grid=grid,
        batches=batches,
        semester_roman=semester_roman,
        subjects_summary=subjects_summary,
        all_faculty=all_faculty,
        all_rooms=all_rooms,
        all_subjects=all_subjects
    )

# ==========================================
# 3. INTERACTIVE SLOT EDITING & CONFLICT API
# ==========================================
@app.route('/api/check_conflict', methods=['POST'])
def api_check_conflict():
    data = request.get_json() or {}
    timetable_id = data.get('timetable_id')
    day = data.get('day_of_week')
    slot = data.get('slot_number')
    faculty_id = data.get('faculty_id') or None
    room_id = data.get('room_id') or None
    exclude_entry_id = data.get('exclude_entry_id') or None
    batch = data.get('batch_name') or 'ALL'

    if not day or not slot:
        return jsonify({'has_conflict': False, 'conflicts': []})

    conn = get_db_connection()
    has_conflict, conflicts = check_slot_conflict(
        conn, timetable_id, day, int(slot),
        int(faculty_id) if faculty_id else None,
        int(room_id) if room_id else None,
        int(exclude_entry_id) if exclude_entry_id else None,
        batch
    )
    conn.close()

    return jsonify({'has_conflict': has_conflict, 'conflicts': conflicts})

@app.route('/timetable/<int:timetable_id>/edit-slot', methods=['POST'])
def edit_timetable_slot(timetable_id):
    entry_id = request.form.get('entry_id', type=int)
    day = request.form.get('day_of_week')
    slot = request.form.get('slot_number', type=int)
    subject_id = request.form.get('subject_id', type=int) or None
    faculty_id = request.form.get('faculty_id', type=int) or None
    room_id = request.form.get('room_id', type=int) or None
    entry_type = request.form.get('entry_type', default='Theory')
    batch_name = request.form.get('batch_name', default='ALL')

    conn = get_db_connection()
    cursor = conn.cursor()

    # Validate conflict
    has_conflict, conflicts = check_slot_conflict(
        conn, timetable_id, day, slot, faculty_id, room_id, entry_id, batch_name
    )

    if has_conflict and not request.form.get('force_override'):
        conn.close()
        flash(f"Conflict detected: {conflicts[0]}", "warning")
        return redirect(url_for('view_timetable', timetable_id=timetable_id))

    if entry_id:
        cursor.execute("""
            UPDATE timetable_entries
            SET day_of_week = ?, slot_number = ?, subject_id = ?, faculty_id = ?,
                room_id = ?, entry_type = ?, batch_name = ?
            WHERE id = ? AND timetable_id = ?
        """, (day, slot, subject_id, faculty_id, room_id, entry_type, batch_name, entry_id, timetable_id))
    else:
        cursor.execute("""
            INSERT INTO timetable_entries (timetable_id, day_of_week, slot_number, subject_id, faculty_id, room_id, entry_type, batch_name)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (timetable_id, day, slot, subject_id, faculty_id, room_id, entry_type, batch_name))

    conn.commit()
    conn.close()
    flash("Timetable slot successfully updated!", "success")
    return redirect(url_for('view_timetable', timetable_id=timetable_id))

@app.route('/timetable/<int:timetable_id>/delete-slot/<int:entry_id>', methods=['POST'])
def delete_timetable_slot(timetable_id, entry_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM timetable_entries WHERE id = ? AND timetable_id = ?", (entry_id, timetable_id))
    conn.commit()
    conn.close()
    flash("Slot cleared successfully.", "info")
    return redirect(url_for('view_timetable', timetable_id=timetable_id))

@app.route('/timetable/<int:timetable_id>/delete', methods=['POST'])
def delete_timetable(timetable_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM timetables WHERE id = ?", (timetable_id,))
    conn.commit()
    conn.close()
    flash("Timetable deleted successfully.", "success")
    return redirect(url_for('timetables_list'))

# ==========================================
# 4. EXPORT & PRINT ROUTES
# ==========================================
@app.route('/timetable/<int:timetable_id>/export/pdf')
def export_pdf(timetable_id):
    scratch_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'exports')
    os.makedirs(scratch_dir, exist_ok=True)
    pdf_path = os.path.join(scratch_dir, f'DYPCET_Timetable_{timetable_id}.pdf')

    try:
        generate_pdf(timetable_id, pdf_path)
        return send_file(pdf_path, as_attachment=True, download_name=f'DYPCET_Timetable_{timetable_id}.pdf', mimetype='application/pdf')
    except Exception as e:
        flash(f"Error generating PDF: {str(e)}", "danger")
        return redirect(url_for('view_timetable', timetable_id=timetable_id))

@app.route('/timetable/<int:timetable_id>/export/excel')
def export_excel(timetable_id):
    scratch_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'exports')
    os.makedirs(scratch_dir, exist_ok=True)
    xlsx_path = os.path.join(scratch_dir, f'DYPCET_Timetable_{timetable_id}.xlsx')

    try:
        generate_excel(timetable_id, xlsx_path)
        return send_file(xlsx_path, as_attachment=True, download_name=f'DYPCET_Timetable_{timetable_id}.xlsx',
                         mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    except Exception as e:
        flash(f"Error generating Excel: {str(e)}", "danger")
        return redirect(url_for('view_timetable', timetable_id=timetable_id))

@app.route('/timetable/<int:timetable_id>/print')
@login_required
def print_timetable(timetable_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    tt = cursor.execute("""
        SELECT t.*, d.code as dept_code, d.name as dept_name, d.hod_name,
               div.name as div_name, div.class_coordinator, div.student_count, div.batches_count
        FROM timetables t
        JOIN departments d ON t.dept_id = d.id
        JOIN divisions div ON t.division_id = div.id
        WHERE t.id = ?
    """, (timetable_id,)).fetchone()

    slots = cursor.execute("""
        SELECT DISTINCT slot_number, start_time, end_time, is_break, break_name
        FROM time_slots
        WHERE day_of_week = 'Monday'
        ORDER BY slot_number ASC
    """).fetchall()

    entries = cursor.execute("""
        SELECT te.*, s.name as subject_name, s.short_name, s.color as subject_color, s.subject_code,
               f.name as faculty_name, f.faculty_code,
               r.room_number, r.room_type
        FROM timetable_entries te
        LEFT JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON te.faculty_id = f.id
        LEFT JOIN rooms r ON te.room_id = r.id
        WHERE te.timetable_id = ?
        ORDER BY te.day_of_week, te.slot_number, te.batch_name ASC
    """, (timetable_id,)).fetchall()

    subjects_summary = cursor.execute("""
        SELECT DISTINCT s.id, s.subject_code, s.name, s.short_name, s.subject_type,
               s.lecture_hours_per_week, s.practical_hours_per_week, s.credits,
               f.name as faculty_name, f.faculty_code
        FROM timetable_entries te
        JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON s.primary_faculty_id = f.id
        WHERE te.timetable_id = ?
        ORDER BY s.subject_code ASC
    """, (timetable_id,)).fetchall()

    conn.close()

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    grid = {day: {s['slot_number']: [] for s in slots} for day in days}

    for e in entries:
        day = e['day_of_week']
        slot = e['slot_number']
        if day in grid and slot in grid[day]:
            grid[day][slot].append(dict(e))

    db_batches = [e['batch_name'] for e in entries if e['batch_name'] and e['batch_name'] != 'ALL']
    unique_batches = sorted(list(set(db_batches)))
    if not unique_batches:
        pfx = 'T' if 'TY' in (tt['div_name'] or tt['year_name'] or '') else 'A'
        unique_batches = [f"{pfx}{i+1}" for i in range(tt['batches_count'] or 3)]
    batches = unique_batches

    roman_map = {1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V', 6: 'VI', 7: 'VII', 8: 'VIII'}
    semester_roman = roman_map.get(tt['semester'], str(tt['semester']))

    return render_template(
        'print_view.html',
        tt=tt,
        slots=slots,
        days=days,
        grid=grid,
        batches=batches,
        semester_roman=semester_roman,
        subjects_summary=subjects_summary
    )

# ==========================================
# 5. GENERATOR CENTER
# ==========================================
@app.route('/generate', methods=['GET', 'POST'])
@login_required
def generate_center():
    conn = get_db_connection()
    depts = conn.execute("SELECT * FROM departments ORDER BY code ASC").fetchall()
    divisions = conn.execute("""
        SELECT div.*, d.code as dept_code, d.name as dept_name
        FROM divisions div
        JOIN departments d ON div.dept_id = d.id
        ORDER BY d.code, div.semester, div.name ASC
    """).fetchall()
    conn.close()

    if request.method == 'POST':
        division_id = request.form.get('division_id', type=int)
        academic_year = request.form.get('academic_year', default='2026-2027')
        term = request.form.get('term', default='Odd Term')

        if not division_id:
            flash("Please select a target Division.", "warning")
            return redirect(url_for('generate_center'))

        try:
            gen = TimetableGenerator(division_id, academic_year, term)
            timetable_id, fitness_score, log_summary = gen.generate()
            flash(f"Timetable generated successfully with {fitness_score}% optimal fitness score!", "success")
            return redirect(url_for('view_timetable', timetable_id=timetable_id))
        except Exception as e:
            flash(f"Generation error: {str(e)}", "danger")
            return redirect(url_for('generate_center'))

    return render_template('generate.html', departments=depts, divisions=divisions)

# ==========================================
# 6. FACULTY DIRECTORY & WORKLOAD
# ==========================================
@app.route('/faculty', methods=['GET', 'POST'])
@login_required
def faculty_list():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        faculty_code = request.form.get('faculty_code')
        name = request.form.get('name')
        dept_id = request.form.get('dept_id', type=int)
        designation = request.form.get('designation')
        email = request.form.get('email')
        phone = request.form.get('phone')
        max_hours = request.form.get('max_hours_per_week', default=18, type=int)
        color = request.form.get('color', default='#1d4ed8')

        try:
            cursor.execute("""
                INSERT INTO faculty (faculty_code, name, dept_id, designation, email, phone, max_hours_per_week, color)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (faculty_code, name, dept_id, designation, email, phone, max_hours, color))
            conn.commit()
            flash(f"Faculty '{name}' added successfully!", "success")
        except Exception as e:
            flash(f"Error adding faculty: {str(e)}", "danger")

        conn.close()
        return redirect(url_for('faculty_list'))

    # Load faculty with assigned workload hours calculated dynamically
    faculty_members = cursor.execute("""
        SELECT f.*, d.code as dept_code, d.name as dept_name,
               (SELECT COUNT(DISTINCT te.day_of_week || '-' || te.slot_number)
                FROM timetable_entries te
                WHERE te.faculty_id = f.id) as assigned_hours
        FROM faculty f
        JOIN departments d ON f.dept_id = d.id
        WHERE f.is_active = 1
        ORDER BY d.code, f.name ASC
    """).fetchall()

    depts = cursor.execute("SELECT * FROM departments ORDER BY code ASC").fetchall()
    conn.close()

    return render_template('faculty.html', faculty=faculty_members, departments=depts)

@app.route('/faculty/<int:faculty_id>/timetable')
@login_required
def faculty_personal_timetable(faculty_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    faculty_member = cursor.execute("""
        SELECT f.*, d.code as dept_code, d.name as dept_name
        FROM faculty f
        JOIN departments d ON f.dept_id = d.id
        WHERE f.id = ?
    """, (faculty_id,)).fetchone()

    if not faculty_member:
        conn.close()
        flash("Faculty member not found.", "danger")
        return redirect(url_for('faculty_list'))

    slots = cursor.execute("""
        SELECT DISTINCT slot_number, start_time, end_time, is_break, break_name
        FROM time_slots
        WHERE day_of_week = 'Monday'
        ORDER BY slot_number ASC
    """).fetchall()

    entries = cursor.execute("""
        SELECT te.*, s.name as subject_name, s.short_name, s.subject_code, s.color as subject_color,
               r.room_number, r.room_type,
               t.name as timetable_name, div.name as div_name, div.year_name
        FROM timetable_entries te
        JOIN timetables t ON te.timetable_id = t.id
        JOIN divisions div ON t.division_id = div.id
        LEFT JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN rooms r ON te.room_id = r.id
        WHERE te.faculty_id = ?
        ORDER BY te.day_of_week, te.slot_number ASC
    """, (faculty_id,)).fetchall()

    conn.close()

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    grid = {day: {s['slot_number']: [] for s in slots} for day in days}

    total_hours = 0
    for e in entries:
        day = e['day_of_week']
        slot = e['slot_number']
        if day in grid and slot in grid[day]:
            grid[day][slot].append(dict(e))
            total_hours += 1

    return render_template(
        'faculty_timetable.html',
        faculty=faculty_member,
        slots=slots,
        days=days,
        grid=grid,
        total_hours=total_hours
    )

@app.route('/faculty/<int:faculty_id>/edit', methods=['POST'])
@login_required
def edit_faculty(faculty_id):
    faculty_code = request.form.get('faculty_code', '').strip()
    name = request.form.get('name', '').strip()
    dept_id = request.form.get('dept_id', type=int)
    designation = request.form.get('designation', '').strip()
    email = request.form.get('email', '').strip()
    phone = request.form.get('phone', '').strip()
    max_hours = request.form.get('max_hours_per_week', default=18, type=int)
    color = request.form.get('color', default='#1d4ed8')

    conn = get_db_connection()
    try:
        conn.execute("""
            UPDATE faculty
            SET faculty_code = ?, name = ?, dept_id = ?, designation = ?, email = ?, phone = ?, max_hours_per_week = ?, color = ?
            WHERE id = ?
        """, (faculty_code, name, dept_id, designation, email, phone, max_hours, color, faculty_id))
        conn.commit()
        flash(f"Faculty '{name}' details updated successfully!", "success")
    except Exception as e:
        flash(f"Error updating faculty: {str(e)}", "danger")
    finally:
        conn.close()

    return redirect(url_for('faculty_list'))

@app.route('/faculty/<int:faculty_id>/delete', methods=['POST'])
@login_required
def delete_faculty(faculty_id):
    conn = get_db_connection()
    conn.execute("UPDATE faculty SET is_active = 0 WHERE id = ?", (faculty_id,))
    conn.commit()
    conn.close()
    flash("Faculty archived successfully.", "info")
    return redirect(url_for('faculty_list'))

# ==========================================
# 7. COURSES & SUBJECTS
# ==========================================
@app.route('/subjects', methods=['GET', 'POST'])
@login_required
def subjects_list():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        subject_code = request.form.get('subject_code')
        name = request.form.get('name')
        short_name = request.form.get('short_name')
        dept_id = request.form.get('dept_id', type=int)
        semester = request.form.get('semester', type=int)
        subject_type = request.form.get('subject_type')
        lec_hrs = request.form.get('lecture_hours_per_week', default=3, type=int)
        prac_hrs = request.form.get('practical_hours_per_week', default=0, type=int)
        tut_hrs = request.form.get('tutorial_hours_per_week', default=0, type=int)
        credits = request.form.get('credits', default=3, type=int)
        primary_faculty_id = request.form.get('primary_faculty_id', type=int) or None
        color = request.form.get('color', default='#2563eb')

        try:
            cursor.execute("""
                INSERT INTO subjects (subject_code, name, short_name, dept_id, semester, subject_type,
                                      lecture_hours_per_week, practical_hours_per_week, tutorial_hours_per_week,
                                      credits, primary_faculty_id, color)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (subject_code, name, short_name, dept_id, semester, subject_type,
                  lec_hrs, prac_hrs, tut_hrs, credits, primary_faculty_id, color))
            conn.commit()
            flash(f"Subject '{name}' added successfully!", "success")
        except Exception as e:
            flash(f"Error adding subject: {str(e)}", "danger")

        conn.close()
        return redirect(url_for('subjects_list'))

    subjects = cursor.execute("""
        SELECT s.*, d.code as dept_code, d.name as dept_name,
               f.name as primary_faculty_name, f.faculty_code as primary_faculty_code
        FROM subjects s
        JOIN departments d ON s.dept_id = d.id
        LEFT JOIN faculty f ON s.primary_faculty_id = f.id
        ORDER BY d.code, s.semester, s.subject_code ASC
    """).fetchall()

    depts = cursor.execute("SELECT * FROM departments ORDER BY code ASC").fetchall()
    faculty = cursor.execute("SELECT id, name, faculty_code FROM faculty WHERE is_active = 1 ORDER BY name ASC").fetchall()
    conn.close()

    return render_template('subjects.html', subjects=subjects, departments=depts, faculty=faculty)

@app.route('/subjects/<int:subject_id>/edit', methods=['POST'])
@login_required
def edit_subject(subject_id):
    subject_code = request.form.get('subject_code', '').strip()
    name = request.form.get('name', '').strip()
    short_name = request.form.get('short_name', '').strip()
    dept_id = request.form.get('dept_id', type=int)
    semester = request.form.get('semester', type=int)
    subject_type = request.form.get('subject_type', '').strip()
    lec_hrs = request.form.get('lecture_hours_per_week', default=3, type=int)
    prac_hrs = request.form.get('practical_hours_per_week', default=0, type=int)
    tut_hrs = request.form.get('tutorial_hours_per_week', default=0, type=int)
    credits = request.form.get('credits', default=3, type=int)
    primary_faculty_id = request.form.get('primary_faculty_id', type=int) or None
    color = request.form.get('color', default='#2563eb')

    conn = get_db_connection()
    try:
        conn.execute("""
            UPDATE subjects
            SET subject_code = ?, name = ?, short_name = ?, dept_id = ?, semester = ?, subject_type = ?,
                lecture_hours_per_week = ?, practical_hours_per_week = ?, tutorial_hours_per_week = ?,
                credits = ?, primary_faculty_id = ?, color = ?
            WHERE id = ?
        """, (subject_code, name, short_name, dept_id, semester, subject_type,
              lec_hrs, prac_hrs, tut_hrs, credits, primary_faculty_id, color, subject_id))
        conn.commit()
        flash(f"Subject '{name}' ({subject_code}) updated successfully!", "success")
    except Exception as e:
        flash(f"Error updating subject: {str(e)}", "danger")
    finally:
        conn.close()

    return redirect(url_for('subjects_list'))

@app.route('/subjects/<int:subject_id>/delete', methods=['POST'])
@login_required
def delete_subject(subject_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM subjects WHERE id = ?", (subject_id,))
    conn.commit()
    conn.close()
    flash("Subject removed successfully.", "info")
    return redirect(url_for('subjects_list'))

# ==========================================
# 8. ROOMS & LABORATORIES
# ==========================================
@app.route('/rooms', methods=['GET', 'POST'])
@login_required
def rooms_list():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        room_number = request.form.get('room_number')
        name = request.form.get('name')
        room_type = request.form.get('room_type')
        capacity = request.form.get('capacity', default=70, type=int)
        floor = request.form.get('floor', default='2nd Floor')
        building = request.form.get('building', default='Main Block')
        dept_id = request.form.get('dept_id', type=int) or None

        try:
            cursor.execute("""
                INSERT INTO rooms (room_number, name, room_type, capacity, floor, building, dept_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (room_number, name, room_type, capacity, floor, building, dept_id))
            conn.commit()
            flash(f"Room '{room_number}' added successfully!", "success")
        except Exception as e:
            flash(f"Error adding room: {str(e)}", "danger")

        conn.close()
        return redirect(url_for('rooms_list'))

    rooms = cursor.execute("""
        SELECT r.*, d.code as dept_code,
               (SELECT COUNT(DISTINCT te.day_of_week || '-' || te.slot_number)
                FROM timetable_entries te
                WHERE te.room_id = r.id) as occupied_slots
        FROM rooms r
        LEFT JOIN departments d ON r.dept_id = d.id
        WHERE r.is_active = 1
        ORDER BY r.room_type, r.room_number ASC
    """).fetchall()

    depts = cursor.execute("SELECT * FROM departments ORDER BY code ASC").fetchall()
    conn.close()

    return render_template('rooms.html', rooms=rooms, departments=depts)

@app.route('/rooms/<int:room_id>/timetable')
@login_required
def room_occupancy_timetable(room_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    room = cursor.execute("SELECT * FROM rooms WHERE id = ?", (room_id,)).fetchone()
    if not room:
        conn.close()
        flash("Room not found.", "danger")
        return redirect(url_for('rooms_list'))

    slots = cursor.execute("""
        SELECT DISTINCT slot_number, start_time, end_time, is_break, break_name
        FROM time_slots
        WHERE day_of_week = 'Monday'
        ORDER BY slot_number ASC
    """).fetchall()

    entries = cursor.execute("""
        SELECT te.*, s.name as subject_name, s.short_name, s.color as subject_color,
               f.name as faculty_name, f.faculty_code,
               t.name as timetable_name, div.name as div_name, div.year_name
        FROM timetable_entries te
        JOIN timetables t ON te.timetable_id = t.id
        JOIN divisions div ON t.division_id = div.id
        LEFT JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON te.faculty_id = f.id
        WHERE te.room_id = ?
        ORDER BY te.day_of_week, te.slot_number ASC
    """, (room_id,)).fetchall()

    conn.close()

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    grid = {day: {s['slot_number']: [] for s in slots} for day in days}

    occupied_count = 0
    for e in entries:
        day = e['day_of_week']
        slot = e['slot_number']
        if day in grid and slot in grid[day]:
            grid[day][slot].append(dict(e))
            occupied_count += 1

    return render_template(
        'room_timetable.html',
        room=room,
        slots=slots,
        days=days,
        grid=grid,
        occupied_count=occupied_count
    )

@app.route('/rooms/<int:room_id>/edit', methods=['POST'])
@login_required
def edit_room(room_id):
    room_number = request.form.get('room_number', '').strip()
    name = request.form.get('name', '').strip()
    room_type = request.form.get('room_type', '').strip()
    capacity = request.form.get('capacity', default=70, type=int)
    floor = request.form.get('floor', default='2nd Floor').strip()
    building = request.form.get('building', default='Main Block').strip()
    dept_id = request.form.get('dept_id', type=int) or None

    conn = get_db_connection()
    try:
        conn.execute("""
            UPDATE rooms
            SET room_number = ?, name = ?, room_type = ?, capacity = ?, floor = ?, building = ?, dept_id = ?
            WHERE id = ?
        """, (room_number, name, room_type, capacity, floor, building, dept_id, room_id))
        conn.commit()
        flash(f"Room '{room_number}' updated successfully!", "success")
    except Exception as e:
        flash(f"Error updating room: {str(e)}", "danger")
    finally:
        conn.close()

    return redirect(url_for('rooms_list'))

@app.route('/rooms/<int:room_id>/delete', methods=['POST'])
@login_required
def delete_room(room_id):
    conn = get_db_connection()
    try:
        conn.execute("UPDATE rooms SET is_active = 0 WHERE id = ?", (room_id,))
        conn.commit()
        flash("Room / Laboratory archived successfully.", "info")
    except Exception as e:
        flash(f"Error archiving room: {str(e)}", "danger")
    finally:
        conn.close()

    return redirect(url_for('rooms_list'))

# ==========================================
# 9. DEPARTMENTS DIRECTORY
# ==========================================
@app.route('/departments')
@login_required
def departments_page():
    conn = get_db_connection()
    depts = conn.execute("""
        SELECT d.*,
               (SELECT COUNT(*) FROM faculty f WHERE f.dept_id = d.id AND f.is_active = 1) as faculty_count,
               (SELECT COUNT(*) FROM subjects s WHERE s.dept_id = d.id) as subjects_count,
               (SELECT COUNT(*) FROM divisions div WHERE div.dept_id = d.id) as divisions_count,
               (SELECT COUNT(*) FROM rooms r WHERE r.dept_id = d.id AND r.is_active = 1) as rooms_count
        FROM departments d
        ORDER BY d.code ASC
    """).fetchall()
    conn.close()
    return render_template('departments.html', departments=depts)

# ==========================================
# 10. FACULTY WORKLOAD DISTRIBUTION & ANALYTICS
# ==========================================
@app.route('/workload')
@login_required
def workload_analytics():
    conn = get_db_connection()
    faculty_workloads = conn.execute("""
        SELECT f.id, f.faculty_code, f.name, f.designation, f.max_hours_per_week, f.color,
               d.code as dept_code, d.name as dept_name,
               COUNT(DISTINCT te.day_of_week || '-' || te.slot_number) as assigned_hours,
               SUM(CASE WHEN te.entry_type = 'Theory' THEN 1 ELSE 0 END) as theory_hours,
               SUM(CASE WHEN te.entry_type = 'Practical' THEN 1 ELSE 0 END) as practical_hours
        FROM faculty f
        JOIN departments d ON f.dept_id = d.id
        LEFT JOIN timetable_entries te ON te.faculty_id = f.id
        WHERE f.is_active = 1
        GROUP BY f.id
        ORDER BY assigned_hours DESC, f.name ASC
    """).fetchall()
    conn.close()

    total_load = sum(fw['assigned_hours'] or 0 for fw in faculty_workloads)
    total_capacity = sum(fw['max_hours_per_week'] or 18 for fw in faculty_workloads)
    utilization_rate = round((total_load / total_capacity * 100), 1) if total_capacity > 0 else 0

    return render_template(
        'workload.html',
        workloads=faculty_workloads,
        total_load=total_load,
        total_capacity=total_capacity,
        utilization_rate=utilization_rate
    )

# ==========================================
# 11. SETTINGS & DATA RESET
# ==========================================
@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings_page():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        for key in request.form:
            val = request.form[key]
            cursor.execute("INSERT OR REPLACE INTO system_settings (key, value) VALUES (?, ?)", (key, val))
        conn.commit()
        conn.close()
        flash("Institute settings updated successfully!", "success")
        return redirect(url_for('settings_page'))

    settings = get_system_settings()
    conn.close()
    return render_template('settings.html', settings=settings)

@app.route('/settings/reset-demo', methods=['POST'])
@login_required
def reset_demo_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    # Drop and reinitialize tables
    cursor.execute("DROP TABLE IF EXISTS timetable_entries")
    cursor.execute("DROP TABLE IF EXISTS timetables")
    cursor.execute("DROP TABLE IF EXISTS subjects")
    cursor.execute("DROP TABLE IF EXISTS faculty")
    cursor.execute("DROP TABLE IF EXISTS rooms")
    cursor.execute("DROP TABLE IF EXISTS divisions")
    cursor.execute("DROP TABLE IF EXISTS time_slots")
    cursor.execute("DROP TABLE IF EXISTS departments")
    cursor.execute("DROP TABLE IF EXISTS system_settings")
    conn.commit()
    conn.close()

    init_db()
    flash("Database reset to DYPCET default academic sample data!", "success")
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    # Run locally on port 5001 to avoid clashes
    app.run(host='0.0.0.0', port=5001, debug=True)
