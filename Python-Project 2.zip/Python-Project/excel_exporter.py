import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from database import get_db_connection

def generate_excel(timetable_id, output_path):
    conn = get_db_connection()
    cursor = conn.cursor()

    tt = cursor.execute("""
        SELECT t.*, d.code as dept_code, d.name as dept_name,
               div.name as div_name, div.class_coordinator
        FROM timetables t
        JOIN departments d ON t.dept_id = d.id
        JOIN divisions div ON t.division_id = div.id
        WHERE t.id = ?
    """, (timetable_id,)).fetchone()

    if not tt:
        conn.close()
        raise ValueError("Timetable not found.")

    slots = cursor.execute("""
        SELECT DISTINCT slot_number, start_time, end_time, is_break, break_name
        FROM time_slots
        WHERE day_of_week = 'Monday'
        ORDER BY slot_number ASC
    """).fetchall()

    raw_entries = cursor.execute("""
        SELECT te.*, s.short_name as subject_name, s.name as full_subject_name,
               s.subject_code, f.faculty_code, f.name as faculty_name,
               r.room_number
        FROM timetable_entries te
        LEFT JOIN subjects s ON te.subject_id = s.id
        LEFT JOIN faculty f ON te.faculty_id = f.id
        LEFT JOIN rooms r ON te.room_id = r.id
        WHERE te.timetable_id = ?
        ORDER BY te.day_of_week, te.slot_number, te.batch_name ASC
    """, (timetable_id,)).fetchall()

    settings_rows = cursor.execute("SELECT key, value FROM system_settings").fetchall()
    settings = {r['key']: r['value'] for r in settings_rows}

    conn.close()

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    grid = {d: {s['slot_number']: [] for s in slots} for d in days}

    for e in raw_entries:
        day = e['day_of_week']
        slot = e['slot_number']
        if day in grid and slot in grid[day]:
            if e['entry_type'] == 'Practical':
                batch = e['batch_name'] or 'Lab'
                sub = e['subject_name'] or 'PRAC'
                room = e['room_number'] or ''
                fac = e['faculty_code'] or ''
                grid[day][slot].append(f"{batch}: {sub} ({room}/{fac})")
            elif e['entry_type'] == 'Theory':
                sub = e['subject_name'] or 'Theory'
                room = e['room_number'] or ''
                fac = e['faculty_code'] or ''
                grid[day][slot].append(f"{sub} - {room} ({fac})")
            elif e['entry_type'] == 'Tutorial':
                sub = e['subject_name'] or 'Tut'
                fac = e['faculty_code'] or ''
                grid[day][slot].append(f"{sub} (Tut) - {fac}")
            else:
                grid[day][slot].append(f"{e['entry_type']}")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"{tt['year_name']}-{tt['div_name']}"

    # Colors & Fonts
    navy_fill = PatternFill(start_color="0A2558", end_color="0A2558", fill_type="solid")
    sub_navy_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    break_fill = PatternFill(start_color="FED7AA", end_color="FED7AA", fill_type="solid")
    day_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")

    white_bold = Font(name="Arial", size=11, bold=True, color="FFFFFF")
    white_large = Font(name="Arial", size=14, bold=True, color="FFFFFF")
    navy_bold = Font(name="Arial", size=11, bold=True, color="0A2558")
    bold_font = Font(name="Arial", size=10, bold=True)
    normal_font = Font(name="Arial", size=9)
    break_font = Font(name="Arial", size=9, bold=True, color="9A3412")

    thin_border = Border(
        left=Side(style='thin', color='CBD5E1'),
        right=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='CBD5E1'),
        bottom=Side(style='thin', color='CBD5E1')
    )

    center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # 1. College Header
    num_cols = len(slots) + 1
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=num_cols)
    cell = ws.cell(row=1, column=1)
    cell.value = settings.get('college_name', 'D. Y. PATIL COLLEGE OF ENGINEERING & TECHNOLOGY, KOLHAPUR')
    cell.font = white_large
    cell.fill = navy_fill
    cell.alignment = center_align

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=num_cols)
    cell2 = ws.cell(row=2, column=1)
    cell2.value = f"DEPARTMENT OF {tt['dept_name'].upper()} | ACADEMIC YEAR {tt['academic_year']} ({tt['term'].upper()})"
    cell2.font = white_bold
    cell2.fill = sub_navy_fill
    cell2.alignment = center_align

    ws.merge_cells(start_row=3, start_column=1, end_row=3, end_column=num_cols)
    cell3 = ws.cell(row=3, column=1)
    cell3.value = f"Class: {tt['year_name']} (Semester {tt['semester']}) | Division: {tt['div_name']} | Coordinator: {tt['class_coordinator'] or 'Faculty Incharge'}"
    cell3.font = bold_font
    cell3.alignment = center_align

    # 2. Table Headers
    ws.cell(row=5, column=1, value="Day / Time").font = white_bold
    ws.cell(row=5, column=1).fill = navy_fill
    ws.cell(row=5, column=1).alignment = center_align
    ws.cell(row=5, column=1).border = thin_border

    for col_idx, s in enumerate(slots, start=2):
        cell = ws.cell(row=5, column=col_idx)
        if s['is_break']:
            cell.value = f"{s['break_name']}\n{s['start_time']} - {s['end_time']}"
            cell.fill = break_fill
            cell.font = break_font
        else:
            cell.value = f"Slot {s['slot_number']}\n{s['start_time']} - {s['end_time']}"
            cell.fill = navy_fill
            cell.font = white_bold
        cell.alignment = center_align
        cell.border = thin_border

    # 3. Grid Rows
    for row_idx, day in enumerate(days, start=6):
        day_cell = ws.cell(row=row_idx, column=1, value=day)
        day_cell.fill = day_fill
        day_cell.font = bold_font
        day_cell.alignment = center_align
        day_cell.border = thin_border

        for col_idx, s in enumerate(slots, start=2):
            cell = ws.cell(row=row_idx, column=col_idx)
            slot_num = s['slot_number']
            if s['is_break']:
                cell.value = s['break_name']
                cell.fill = break_fill
                cell.font = break_font
            else:
                entries_txt = "\n".join(grid[day][slot_num]) if grid[day][slot_num] else "-"
                cell.value = entries_txt
                cell.font = normal_font
            cell.alignment = center_align
            cell.border = thin_border
        ws.row_dimensions[row_idx].height = 45

    # Column Widths
    ws.column_dimensions['A'].width = 16
    for col_idx in range(2, num_cols + 1):
        col_letter = openpyxl.utils.get_column_letter(col_idx)
        ws.column_dimensions[col_letter].width = 20

    ws.row_dimensions[1].height = 30
    ws.row_dimensions[2].height = 24
    ws.row_dimensions[3].height = 20
    ws.row_dimensions[5].height = 32

    wb.save(output_path)
    return output_path
