import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dypcet_timetable.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # System Settings Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS system_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )
    ''')

    # Users Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT UNIQUE,
        role TEXT NOT NULL DEFAULT 'Faculty', -- 'Admin', 'Coordinator', 'HOD', 'Faculty', 'Student'
        dept_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE SET NULL
    )
    ''')

    # Departments Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        hod_name TEXT NOT NULL,
        building TEXT DEFAULT 'Main Engineering Block',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Divisions Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS divisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        dept_id INTEGER NOT NULL,
        year_name TEXT NOT NULL, -- FE, SE, TE, BE
        semester INTEGER NOT NULL,
        name TEXT NOT NULL, -- Div A, Div B, etc.
        class_coordinator TEXT,
        student_count INTEGER DEFAULT 65,
        batches_count INTEGER DEFAULT 3, -- A1, A2, A3
        FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE CASCADE
    )
    ''')

    # Classrooms and Labs
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_number TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        room_type TEXT NOT NULL, -- 'Classroom', 'Computer Lab', 'Hardware Lab', 'Workshop', 'Seminar Hall'
        capacity INTEGER NOT NULL DEFAULT 70,
        floor TEXT DEFAULT '2nd Floor',
        building TEXT DEFAULT 'Main Block',
        dept_id INTEGER,
        is_active INTEGER DEFAULT 1,
        FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE SET NULL
    )
    ''')

    # Faculty Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS faculty (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        faculty_code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        dept_id INTEGER NOT NULL,
        designation TEXT NOT NULL, -- Professor, Associate Professor, Assistant Professor
        email TEXT,
        phone TEXT,
        max_hours_per_week INTEGER DEFAULT 18,
        color TEXT DEFAULT '#1d4ed8',
        is_active INTEGER DEFAULT 1,
        FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE CASCADE
    )
    ''')

    # Subjects / Courses Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        short_name TEXT NOT NULL,
        dept_id INTEGER NOT NULL,
        semester INTEGER NOT NULL,
        subject_type TEXT NOT NULL, -- 'Theory', 'Practical', 'Theory + Practical', 'Tutorial'
        lecture_hours_per_week INTEGER DEFAULT 3,
        practical_hours_per_week INTEGER DEFAULT 0, -- 2 hours per batch
        tutorial_hours_per_week INTEGER DEFAULT 0,
        credits INTEGER DEFAULT 3,
        primary_faculty_id INTEGER,
        lab_faculty_ids TEXT, -- comma separated IDs
        preferred_room_type TEXT DEFAULT 'Classroom',
        color TEXT DEFAULT '#2563eb',
        FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE CASCADE,
        FOREIGN KEY (primary_faculty_id) REFERENCES faculty(id) ON DELETE SET NULL
    )
    ''')

    # Time Slot Structure Definition
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS time_slots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slot_number INTEGER NOT NULL,
        day_of_week TEXT NOT NULL, -- Monday to Saturday
        day_order INTEGER NOT NULL, -- 1 to 6
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        is_break INTEGER DEFAULT 0,
        break_name TEXT
    )
    ''')

    # Timetables Master Record
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS timetables (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        dept_id INTEGER NOT NULL,
        year_name TEXT NOT NULL,
        semester INTEGER NOT NULL,
        division_id INTEGER NOT NULL,
        academic_year TEXT DEFAULT '2026-2027',
        term TEXT DEFAULT 'Odd Term',
        fitness_score REAL DEFAULT 100.0,
        status TEXT DEFAULT 'Generated', -- Draft, Generated, Approved, Published
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        notes TEXT,
        FOREIGN KEY (dept_id) REFERENCES departments(id) ON DELETE CASCADE,
        FOREIGN KEY (division_id) REFERENCES divisions(id) ON DELETE CASCADE
    )
    ''')

    # Timetable Entries / Allocation Slots
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS timetable_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timetable_id INTEGER NOT NULL,
        day_of_week TEXT NOT NULL,
        slot_number INTEGER NOT NULL,
        subject_id INTEGER,
        faculty_id INTEGER,
        room_id INTEGER,
        entry_type TEXT NOT NULL, -- 'Theory', 'Practical', 'Tutorial', 'Break', 'Library/Sports'
        batch_name TEXT DEFAULT 'ALL', -- 'ALL' or 'A1', 'A2', 'A3'
        is_consecutive_second_hour INTEGER DEFAULT 0,
        FOREIGN KEY (timetable_id) REFERENCES timetables(id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
        FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE SET NULL,
        FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL
    )
    ''')

    conn.commit()

    # Seed Default Settings and College Data if empty
    seed_default_data(conn)
    conn.close()

def seed_default_data(conn):
    cursor = conn.cursor()

    # Check if already seeded
    cursor.execute("SELECT COUNT(*) FROM departments")
    if cursor.fetchone()[0] > 0:
        return

    # 1. System Settings
    settings = [
        ('college_name', 'D. Y. Patil College of Engineering & Technology'),
        ('college_subtitle', 'Autonomous Institute | Accredited "A" Grade by NAAC | Approved by AICTE New Delhi'),
        ('college_address', 'Kasaba Bawada, Kolhapur, Maharashtra - 416006'),
        ('college_phone', '+91 231 2601431 / 33'),
        ('college_email', 'info@dypcet.edu.in'),
        ('college_website', 'dypgroup.edu.in'),
        ('academic_year', '2026-2027'),
        ('term', 'Odd Term'),
        ('principal_title', 'Dr. S. D. Chede (Principal)'),
        ('dean_academics_title', 'Dr. K. V. Kulhalli (Dean Academics)'),
        ('hod_signature_title', 'Head of Department'),
        ('timetable_incharge_title', 'Timetable Coordinator'),
        ('working_days', 'Monday,Tuesday,Wednesday,Thursday,Friday,Saturday')
    ]
    cursor.executemany("INSERT OR REPLACE INTO system_settings (key, value) VALUES (?, ?)", settings)

    # 2. Standard Time Slots Definition (Slot 1 to 7 with Tea Break & Lunch Break)
    # College hours: 09:15 AM to 05:15 PM
    days = [
        ('Monday', 1),
        ('Tuesday', 2),
        ('Wednesday', 3),
        ('Thursday', 4),
        ('Friday', 5),
        ('Saturday', 6)
    ]

    base_slots = [
        (1, '09:15 AM', '10:15 AM', 0, None),
        (2, '10:15 AM', '11:15 AM', 0, None),
        (3, '11:15 AM', '11:30 AM', 1, 'Short Tea Break'),
        (4, '11:30 AM', '12:30 PM', 0, None),
        (5, '12:30 PM', '01:30 PM', 0, None),
        (6, '01:30 PM', '02:15 PM', 1, 'Lunch Break'),
        (7, '02:15 PM', '03:15 PM', 0, None),
        (8, '03:15 PM', '04:15 PM', 0, None),
        (9, '04:15 PM', '05:15 PM', 0, None),
    ]

    for day_name, day_order in days:
        # On Saturday, college operates half day (up to lunch break)
        day_slots = base_slots if day_name != 'Saturday' else base_slots[:6]
        for slot_num, start_t, end_t, is_brk, brk_name in day_slots:
            cursor.execute('''
            INSERT INTO time_slots (slot_number, day_of_week, day_order, start_time, end_time, is_break, break_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (slot_num, day_name, day_order, start_t, end_t, is_brk, brk_name))

    # 3. Departments of DYPCET
    depts = [
        ('CSE', 'Computer Science & Engineering', 'Dr. S. S. Patil', 'Main Engineering Block, 3rd Floor'),
        ('AIDS', 'Artificial Intelligence & Data Science', 'Dr. B. D. Jitkar', 'Innovation Block, 2nd Floor'),
        ('ENTC', 'Electronics & Telecommunication Engineering', 'Dr. S. V. Sankpal', 'Main Block, 1st Floor'),
        ('MECH', 'Mechanical Engineering', 'Dr. A. N. Jadhav', 'Workshop & Mechanical Wing'),
        ('CIVIL', 'Civil Engineering', 'Dr. M. M. Mujumdar', 'Civil Engineering Block')
    ]
    cursor.executemany("INSERT INTO departments (code, name, hod_name, building) VALUES (?, ?, ?, ?)", depts)

    # 4. Rooms and Labs
    rooms = [
        ('LH-201', 'Lecture Hall 201 (Smart AC Class)', 'Classroom', 75, '2nd Floor', 'Main Block', 1),
        ('LH-202', 'Lecture Hall 202', 'Classroom', 75, '2nd Floor', 'Main Block', 1),
        ('LH-203', 'Lecture Hall 203', 'Classroom', 75, '2nd Floor', 'Main Block', 2),
        ('LH-101', 'Lecture Hall 101', 'Classroom', 80, '1st Floor', 'Main Block', 3),
        ('LH-102', 'Lecture Hall 102', 'Classroom', 80, '1st Floor', 'Main Block', 4),
        ('LAB-301', 'Advanced Computing & AI Lab', 'Computer Lab', 40, '3rd Floor', 'CSE Wing', 1),
        ('LAB-302', 'Database & Web Technologies Lab', 'Computer Lab', 40, '3rd Floor', 'CSE Wing', 1),
        ('LAB-303', 'Software Engineering & Network Lab', 'Computer Lab', 40, '3rd Floor', 'CSE Wing', 1),
        ('LAB-204', 'Machine Learning & Big Data Lab', 'Computer Lab', 40, '2nd Floor', 'Innovation Block', 2),
        ('LAB-105', 'IoT & Embedded Systems Lab', 'Hardware Lab', 35, '1st Floor', 'ENTC Wing', 3),
        ('SEM-HALL', 'Chhatrapati Shivaji Maharaj Seminar Hall', 'Seminar Hall', 150, 'Ground Floor', 'Auditorium Wing', 1),
    ]
    cursor.executemany('''
    INSERT INTO rooms (room_number, name, room_type, capacity, floor, building, dept_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', rooms)

    # 5. Divisions for CSE & AIDS
    # CSE Dept ID = 1, AIDS Dept ID = 2
    divisions = [
        (1, 'SE', 3, 'Div A', 'Prof. P. R. Patil', 68, 3),
        (1, 'SE', 3, 'Div B', 'Prof. S. R. Kulkarni', 66, 3),
        (1, 'TE', 5, 'Div A', 'Prof. A. K. Gupta', 65, 3),
        (2, 'SE', 3, 'Div A', 'Prof. V. V. Mangave', 64, 3),
    ]
    cursor.executemany('''
    INSERT INTO divisions (dept_id, year_name, semester, name, class_coordinator, student_count, batches_count)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', divisions)

    # 6. Faculty Directory
    faculty_list = [
        ('DR_SSP', 'Dr. S. S. Patil', 1, 'Professor & HOD', 'sspatil@dypcet.edu.in', '+91 9822011221', 14, '#1e3a8a'),
        ('DR_AKG', 'Dr. A. K. Gupta', 1, 'Associate Professor', 'akgupta@dypcet.edu.in', '+91 9822011222', 16, '#0369a1'),
        ('PROF_PRP', 'Prof. P. R. Patil', 1, 'Assistant Professor', 'prpatil@dypcet.edu.in', '+91 9822011223', 18, '#15803d'),
        ('PROF_SRK', 'Prof. S. R. Kulkarni', 1, 'Assistant Professor', 'srkulkarni@dypcet.edu.in', '+91 9822011224', 18, '#b45309'),
        ('PROF_MAS', 'Prof. M. A. Shinde', 1, 'Assistant Professor', 'mashinde@dypcet.edu.in', '+91 9822011225', 18, '#6d28d9'),
        ('PROF_NSP', 'Prof. N. S. Powar', 1, 'Assistant Professor', 'nspowar@dypcet.edu.in', '+91 9822011226', 18, '#be185d'),
        ('DR_BDJ', 'Dr. B. D. Jitkar', 2, 'Professor & HOD', 'bdjitkar@dypcet.edu.in', '+91 9822011227', 14, '#0f766e'),
        ('PROF_VVM', 'Prof. V. V. Mangave', 2, 'Assistant Professor', 'vvmangave@dypcet.edu.in', '+91 9822011228', 18, '#4338ca'),
        ('PROF_RBJ', 'Prof. R. B. Jadhav', 1, 'Assistant Professor', 'rbjadhav@dypcet.edu.in', '+91 9822011229', 18, '#c2410c'),
        ('PROF_TDG', 'Prof. T. D. Gaikwad', 2, 'Assistant Professor', 'tdgaikwad@dypcet.edu.in', '+91 9822011230', 18, '#047857')
    ]
    cursor.executemany('''
    INSERT INTO faculty (faculty_code, name, dept_id, designation, email, phone, max_hours_per_week, color)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', faculty_list)

    # 7. Subjects for CSE SE (Semester 3)
    # Theory: 3-4 hrs/wk, Practical: 2 hrs/batch, Tutorial: 1 hr
    subjects_list = [
        # (code, name, short_name, dept_id, sem, type, lec_hrs, prac_hrs, tut_hrs, creds, faculty_id, room_type, color)
        ('CS301', 'Data Structures & Algorithms', 'DSA', 1, 3, 'Theory + Practical', 3, 2, 0, 4, 1, 'Computer Lab', '#1d4ed8'),
        ('CS302', 'Database Management Systems', 'DBMS', 1, 3, 'Theory + Practical', 3, 2, 0, 4, 2, 'Computer Lab', '#0284c7'),
        ('CS303', 'Computer Networks & Security', 'CNS', 1, 3, 'Theory + Practical', 3, 2, 0, 4, 3, 'Computer Lab', '#059669'),
        ('CS304', 'Discrete Mathematical Structures', 'DMS', 1, 3, 'Theory', 4, 0, 1, 4, 5, 'Classroom', '#7c3aed'),
        ('CS305', 'Software Engineering Principles', 'SEP', 1, 3, 'Theory', 3, 0, 0, 3, 6, 'Classroom', '#b45309'),
        ('CS306', 'Object Oriented Programming with Java', 'JAVA-LAB', 1, 3, 'Practical', 0, 2, 0, 2, 9, 'Computer Lab', '#dc2626'),
        ('CS307', 'Professional Communication & Ethics', 'PCE', 1, 3, 'Theory', 2, 0, 0, 2, 4, 'Classroom', '#475569'),
    ]
    cursor.executemany('''
    INSERT INTO subjects (subject_code, name, short_name, dept_id, semester, subject_type,
                          lecture_hours_per_week, practical_hours_per_week, tutorial_hours_per_week,
                          credits, primary_faculty_id, preferred_room_type, color)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', subjects_list)

    conn.commit()

    # Pre-generate a high-quality initial timetable for Division A so user sees immediate results
    create_sample_timetable_entry(conn)

def create_sample_timetable_entry(conn):
    cursor = conn.cursor()
    # Check if timetable exists
    cursor.execute("SELECT COUNT(*) FROM timetables")
    if cursor.fetchone()[0] > 0:
        return

    cursor.execute('''
    INSERT INTO timetables (name, dept_id, year_name, semester, division_id, academic_year, term, fitness_score, status, notes)
    VALUES ('CSE - SE (Sem III) Division A - Master Schedule', 1, 'SE', 3, 1, '2026-2027', 'Odd Term', 98.5, 'Approved', 'Autonomous Curriculum Revision 2026')
    ''')
    timetable_id = cursor.lastrowid

    # Detailed allocations for CSE SE Div A:
    # Rooms: LH-201 (id 1), LAB-301 (id 6), LAB-302 (id 7), LAB-303 (id 8)
    # Slots:
    # 1: 09:15-10:15
    # 2: 10:15-11:15
    # 3: Break
    # 4: 11:30-12:30
    # 5: 12:30-01:30
    # 6: Lunch Break
    # 7: 02:15-03:15
    # 8: 03:15-04:15
    # 9: 04:15-05:15

    # Subjects mapping:
    # 1: DSA (Dr. SSP, id 1)
    # 2: DBMS (Dr. AKG, id 2)
    # 3: CNS (Prof. PRP, id 3)
    # 4: DMS (Prof. MAS, id 5)
    # 5: SEP (Prof. NSP, id 6)
    # 6: JAVA-LAB (Prof. RBJ, id 9)
    # 7: PCE (Prof. SRK, id 4)

    # Let's define the weekly schedule:
    # Monday:
    # Slot 1: DSA (Theory) - LH-201
    # Slot 2: DBMS (Theory) - LH-201
    # Slot 4: CNS (Theory) - LH-201
    # Slot 5: DMS (Theory) - LH-201
    # Slot 7, 8: Lab Session 1 (2 hours):
    #   A1: DSA Lab (LAB-301, Dr. SSP)
    #   A2: DBMS Lab (LAB-302, Dr. AKG)
    #   A3: Java Lab (LAB-303, Prof. RBJ)
    # Slot 9: Remedial / Doubt Solving

    # Tuesday:
    # Slot 1, 2: Lab Session 2 (2 hours):
    #   A1: DBMS Lab (LAB-302, Dr. AKG)
    #   A2: Java Lab (LAB-303, Prof. RBJ)
    #   A3: DSA Lab (LAB-301, Dr. SSP)
    # Slot 4: DMS (Theory) - LH-201
    # Slot 5: DSA (Theory) - LH-201
    # Slot 7: SEP (Theory) - LH-201
    # Slot 8: CNS (Theory) - LH-201
    # Slot 9: Library / Technical Activity

    # Wednesday:
    # Slot 1: DBMS (Theory) - LH-201
    # Slot 2: CNS (Theory) - LH-201
    # Slot 4: DMS (Theory) - LH-201
    # Slot 5: SEP (Theory) - LH-201
    # Slot 7, 8: Lab Session 3 (2 hours):
    #   A1: Java Lab (LAB-303, Prof. RBJ)
    #   A2: DSA Lab (LAB-301, Dr. SSP)
    #   A3: DBMS Lab (LAB-302, Dr. AKG)
    # Slot 9: Mentor-Mentee Meeting

    # Thursday:
    # Slot 1: DSA (Theory) - LH-201
    # Slot 2: DBMS (Theory) - LH-201
    # Slot 4: SEP (Theory) - LH-201
    # Slot 5: PCE (Theory) - LH-201
    # Slot 7, 8: Lab Session 4 (2 hours):
    #   A1: CNS Lab (LAB-301, Prof. PRP)
    #   A2: Aptitude & Soft Skills (LAB-302, Prof. SRK)
    #   A3: CNS Lab (LAB-303, Prof. PRP)
    # Slot 9: Sports & Extra Curricular

    # Friday:
    # Slot 1: DMS (Theory) - LH-201
    # Slot 2: PCE (Theory) - LH-201
    # Slot 4: CNS (Theory) - LH-201
    # Slot 5: DMS (Tutorial) - LH-201
    # Slot 7: Value Added Course / NPTEL Hour
    # Slot 8: Project Based Learning (PBL)
    # Slot 9: Department Club Activity

    # Saturday (Half Day):
    # Slot 1: Expert Lecture / Seminar - SEM-HALL
    # Slot 2: Coding Contest / Hackathon Practice - LAB-301
    # Slot 4: Technical Seminar - LH-201
    # Slot 5: Open Lab Session

    entries = [
        # Monday
        (timetable_id, 'Monday', 1, 1, 1, 1, 'Theory', 'ALL', 0), # DSA
        (timetable_id, 'Monday', 2, 2, 2, 1, 'Theory', 'ALL', 0), # DBMS
        (timetable_id, 'Monday', 4, 3, 3, 1, 'Theory', 'ALL', 0), # CNS
        (timetable_id, 'Monday', 5, 4, 5, 1, 'Theory', 'ALL', 0), # DMS
        # Monday Practical Slot 7 (Hour 1)
        (timetable_id, 'Monday', 7, 1, 1, 6, 'Practical', 'A1', 0), # DSA Lab A1
        (timetable_id, 'Monday', 7, 2, 2, 7, 'Practical', 'A2', 0), # DBMS Lab A2
        (timetable_id, 'Monday', 7, 6, 9, 8, 'Practical', 'A3', 0), # Java Lab A3
        # Monday Practical Slot 8 (Hour 2)
        (timetable_id, 'Monday', 8, 1, 1, 6, 'Practical', 'A1', 1),
        (timetable_id, 'Monday', 8, 2, 2, 7, 'Practical', 'A2', 1),
        (timetable_id, 'Monday', 8, 6, 9, 8, 'Practical', 'A3', 1),
        (timetable_id, 'Monday', 9, 7, 4, 1, 'Tutorial', 'ALL', 0), # PCE / Doubt

        # Tuesday
        # Tuesday Practical Slot 1 (Hour 1)
        (timetable_id, 'Tuesday', 1, 2, 2, 7, 'Practical', 'A1', 0), # DBMS Lab A1
        (timetable_id, 'Tuesday', 1, 6, 9, 8, 'Practical', 'A2', 0), # Java Lab A2
        (timetable_id, 'Tuesday', 1, 1, 1, 6, 'Practical', 'A3', 0), # DSA Lab A3
        # Tuesday Practical Slot 2 (Hour 2)
        (timetable_id, 'Tuesday', 2, 2, 2, 7, 'Practical', 'A1', 1),
        (timetable_id, 'Tuesday', 2, 6, 9, 8, 'Practical', 'A2', 1),
        (timetable_id, 'Tuesday', 2, 1, 1, 6, 'Practical', 'A3', 1),
        (timetable_id, 'Tuesday', 4, 4, 5, 1, 'Theory', 'ALL', 0), # DMS
        (timetable_id, 'Tuesday', 5, 1, 1, 1, 'Theory', 'ALL', 0), # DSA
        (timetable_id, 'Tuesday', 7, 5, 6, 1, 'Theory', 'ALL', 0), # SEP
        (timetable_id, 'Tuesday', 8, 3, 3, 1, 'Theory', 'ALL', 0), # CNS
        (timetable_id, 'Tuesday', 9, None, 4, 1, 'Library/Sports', 'ALL', 0),

        # Wednesday
        (timetable_id, 'Wednesday', 1, 2, 2, 1, 'Theory', 'ALL', 0), # DBMS
        (timetable_id, 'Wednesday', 2, 3, 3, 1, 'Theory', 'ALL', 0), # CNS
        (timetable_id, 'Wednesday', 4, 4, 5, 1, 'Theory', 'ALL', 0), # DMS
        (timetable_id, 'Wednesday', 5, 5, 6, 1, 'Theory', 'ALL', 0), # SEP
        # Wednesday Practical Slot 7 (Hour 1)
        (timetable_id, 'Wednesday', 7, 6, 9, 8, 'Practical', 'A1', 0), # Java Lab A1
        (timetable_id, 'Wednesday', 7, 1, 1, 6, 'Practical', 'A2', 0), # DSA Lab A2
        (timetable_id, 'Wednesday', 7, 2, 2, 7, 'Practical', 'A3', 0), # DBMS Lab A3
        # Wednesday Practical Slot 8 (Hour 2)
        (timetable_id, 'Wednesday', 8, 6, 9, 8, 'Practical', 'A1', 1),
        (timetable_id, 'Wednesday', 8, 1, 1, 6, 'Practical', 'A2', 1),
        (timetable_id, 'Wednesday', 8, 2, 2, 7, 'Practical', 'A3', 1),
        (timetable_id, 'Wednesday', 9, None, 1, 1, 'Mentor-Mentee Meeting', 'ALL', 0),

        # Thursday
        (timetable_id, 'Thursday', 1, 1, 1, 1, 'Theory', 'ALL', 0), # DSA
        (timetable_id, 'Thursday', 2, 2, 2, 1, 'Theory', 'ALL', 0), # DBMS
        (timetable_id, 'Thursday', 4, 5, 6, 1, 'Theory', 'ALL', 0), # SEP
        (timetable_id, 'Thursday', 5, 7, 4, 1, 'Theory', 'ALL', 0), # PCE
        # Thursday Practical Slot 7 (Hour 1)
        (timetable_id, 'Thursday', 7, 3, 3, 6, 'Practical', 'A1', 0), # CNS Lab A1
        (timetable_id, 'Thursday', 7, 3, 3, 7, 'Practical', 'A2', 0), # CNS Lab A2
        (timetable_id, 'Thursday', 7, 3, 3, 8, 'Practical', 'A3', 0), # CNS Lab A3
        # Thursday Practical Slot 8 (Hour 2)
        (timetable_id, 'Thursday', 8, 3, 3, 6, 'Practical', 'A1', 1),
        (timetable_id, 'Thursday', 8, 3, 3, 7, 'Practical', 'A2', 1),
        (timetable_id, 'Thursday', 8, 3, 3, 8, 'Practical', 'A3', 1),
        (timetable_id, 'Thursday', 9, None, None, 1, 'Sports/Yoga', 'ALL', 0),

        # Friday
        (timetable_id, 'Friday', 1, 4, 5, 1, 'Theory', 'ALL', 0), # DMS
        (timetable_id, 'Friday', 2, 7, 4, 1, 'Theory', 'ALL', 0), # PCE
        (timetable_id, 'Friday', 4, 3, 3, 1, 'Theory', 'ALL', 0), # CNS
        (timetable_id, 'Friday', 5, 4, 5, 1, 'Tutorial', 'ALL', 0), # DMS Tutorial
        (timetable_id, 'Friday', 7, None, 6, 6, 'Project Based Learning', 'ALL', 0),
        (timetable_id, 'Friday', 8, None, 6, 6, 'Project Based Learning', 'ALL', 0),
        (timetable_id, 'Friday', 9, None, 3, 1, 'ACM Student Chapter', 'ALL', 0),

        # Saturday
        (timetable_id, 'Saturday', 1, None, 1, 11, 'Guest Lecture / Industry Expert', 'ALL', 0),
        (timetable_id, 'Saturday', 2, None, 9, 6, 'Competitive Coding / Skill Track', 'ALL', 0),
        (timetable_id, 'Saturday', 4, None, 2, 1, 'Technical Seminar', 'ALL', 0),
        (timetable_id, 'Saturday', 5, None, None, 6, 'Open Lab / Practice Session', 'ALL', 0),
    ]

    cursor.executemany('''
    INSERT INTO timetable_entries (timetable_id, day_of_week, slot_number, subject_id, faculty_id, room_id, entry_type, batch_name, is_consecutive_second_hour)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', entries)

    conn.commit()

# Helper queries for the web application
def get_all_departments():
    conn = get_db_connection()
    depts = conn.execute("SELECT * FROM departments ORDER BY code ASC").fetchall()
    conn.close()
    return depts

def get_all_faculty(dept_id=None):
    conn = get_db_connection()
    if dept_id:
        fac = conn.execute("""
            SELECT f.*, d.code as dept_code, d.name as dept_name
            FROM faculty f
            JOIN departments d ON f.dept_id = d.id
            WHERE f.dept_id = ? AND f.is_active = 1
            ORDER BY f.name ASC
        """, (dept_id,)).fetchall()
    else:
        fac = conn.execute("""
            SELECT f.*, d.code as dept_code, d.name as dept_name
            FROM faculty f
            JOIN departments d ON f.dept_id = d.id
            WHERE f.is_active = 1
            ORDER BY d.code, f.name ASC
        """).fetchall()
    conn.close()
    return fac

def get_all_rooms(room_type=None):
    conn = get_db_connection()
    if room_type:
        rooms = conn.execute("SELECT * FROM rooms WHERE room_type = ? AND is_active = 1 ORDER BY room_number ASC", (room_type,)).fetchall()
    else:
        rooms = conn.execute("SELECT * FROM rooms WHERE is_active = 1 ORDER BY room_type, room_number ASC").fetchall()
    conn.close()
    return rooms

def get_all_subjects(dept_id=None, semester=None):
    conn = get_db_connection()
    query = """
        SELECT s.*, d.code as dept_code, f.name as primary_faculty_name, f.faculty_code as primary_faculty_code
        FROM subjects s
        JOIN departments d ON s.dept_id = d.id
        LEFT JOIN faculty f ON s.primary_faculty_id = f.id
        WHERE 1=1
    """
    params = []
    if dept_id:
        query += " AND s.dept_id = ?"
        params.append(dept_id)
    if semester:
        query += " AND s.semester = ?"
        params.append(semester)
    query += " ORDER BY s.semester, s.subject_code ASC"
    subjects = conn.execute(query, params).fetchall()
    conn.close()
    return subjects

def get_all_divisions():
    conn = get_db_connection()
    divs = conn.execute("""
        SELECT div.*, d.code as dept_code, d.name as dept_name
        FROM divisions div
        JOIN departments d ON div.dept_id = d.id
        ORDER BY d.code, div.semester, div.name ASC
    """).fetchall()
    conn.close()
    return divs

def get_time_slots():
    conn = get_db_connection()
    slots = conn.execute("""
        SELECT DISTINCT slot_number, start_time, end_time, is_break, break_name
        FROM time_slots
        WHERE day_of_week = 'Monday'
        ORDER BY slot_number ASC
    """).fetchall()
    conn.close()
    return slots

def get_system_settings():
    conn = get_db_connection()
    rows = conn.execute("SELECT key, value FROM system_settings").fetchall()
    conn.close()
    return {r['key']: r['value'] for r in rows}

def hash_password(password):
    from werkzeug.security import generate_password_hash
    return generate_password_hash(password, method='pbkdf2:sha256')

def check_password(password_hash, password):
    from werkzeug.security import check_password_hash
    try:
        return check_password_hash(password_hash, password)
    except Exception:
        return False

def get_user_by_id(user_id):
    conn = get_db_connection()
    user = conn.execute("""
        SELECT u.*, d.code as dept_code, d.name as dept_name
        FROM users u
        LEFT JOIN departments d ON u.dept_id = d.id
        WHERE u.id = ?
    """, (user_id,)).fetchone()
    conn.close()
    return user

def get_user_by_username(username):
    conn = get_db_connection()
    user = conn.execute("""
        SELECT u.*, d.code as dept_code, d.name as dept_name
        FROM users u
        LEFT JOIN departments d ON u.dept_id = d.id
        WHERE LOWER(u.username) = LOWER(?)
    """, (username,)).fetchone()
    conn.close()
    return user

def create_user(username, password, full_name, email, role='Faculty', dept_id=1):
    conn = get_db_connection()
    cursor = conn.cursor()
    pwd_hash = hash_password(password)
    try:
        cursor.execute('''
            INSERT INTO users (username, password_hash, full_name, email, role, dept_id)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (username, pwd_hash, full_name, email, role, dept_id))
        conn.commit()
        uid = cursor.lastrowid
    finally:
        conn.close()
    return uid

def verify_user(username, password):
    user = get_user_by_username(username)
    if not user:
        return None
    if check_password(user['password_hash'], password):
        return user
    return None

